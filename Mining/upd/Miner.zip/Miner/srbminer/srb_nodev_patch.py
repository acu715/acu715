# -*- coding: utf-8 -*-
"""
SRB 0dev memory patch (no disk modification).

Target: kryptex_SRBMiner-MULTI.exe / SRBMiner-MULTI.exe 3.8.0

Why: SRB implements its dev fee by "forced switch to algorithm 1".
     When the dev pool is unreachable it switches anyway, then waits for a
     job that never arrives; the return path only happens when the dev job
     queue is non-empty, so the GPU sits idle at 0 H/s.

Patch points (found by signature, not by fixed RVA):
  1. switch_algo1  -> xor eax,eax ; ret          (never switch to dev)
  2. timerA        -> mov eax,1 ; ret            (callers treat non-zero as "skip")
  3. timerB        -> xor eax,eax ; ret          (callers treat zero as "skip")

All three are verified unique in the unpacked image. Patch 1 alone would be
enough (all six dev paths funnel through switch_algo1); 2 and 3 just stop the
wasted attempts.

Usage:
  python srb_nodev_patch.py            # patch every SRB process seen, then exit
  python srb_nodev_patch.py --watch    # stay resident, patch new SRB processes

Log: %LOCALAPPDATA%\\srb_nodev_patch.log (ASCII only)
"""
import ctypes
import ctypes.wintypes as wt
import os
import sys
import time

k32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)

PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ = 0x0010
PROCESS_VM_WRITE = 0x0020
PROCESS_VM_OPERATION = 0x0008

MEM_COMMIT = 0x1000
PAGE_NOACCESS = 0x01
PAGE_GUARD = 0x100


class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p),
        ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", wt.DWORD),
        ("RegionSize", ctypes.c_size_t),
        ("State", wt.DWORD),
        ("Protect", wt.DWORD),
        ("Type", wt.DWORD),
    ]


def _readable(protect):
    if protect & PAGE_GUARD:
        return False
    base = protect & 0xFF
    return base not in (0, PAGE_NOACCESS)


PAGE_EXECUTE = 0x10
PAGE_EXECUTE_READ = 0x20
PAGE_EXECUTE_READWRITE = 0x40
PAGE_EXECUTE_WRITECOPY = 0x80
EXEC_PROTECTS = (PAGE_EXECUTE, PAGE_EXECUTE_READ, PAGE_EXECUTE_READWRITE, PAGE_EXECUTE_WRITECOPY)


def _executable(protect):
    if protect & PAGE_GUARD:
        return False
    return (protect & 0xFF) in EXEC_PROTECTS


# name, signature, patch
PATCHES = [
    (
        "switch_algo1",
        bytes([0x41, 0x55, 0x41, 0x54, 0x55, 0x57, 0x56, 0x53,
               0x48, 0x83, 0xEC, 0x38, 0x48, 0x8D, 0x35, 0x1D]),
        bytes([0x31, 0xC0, 0xC3]),                      # xor eax,eax ; ret
    ),
    (
        "timerA",
        bytes([0x55, 0x57, 0x56, 0x53, 0x48, 0x83, 0xEC, 0x28,
               0x48, 0x89, 0xCE, 0xE8, 0x90, 0x77, 0x01, 0x00,
               0x48, 0x8B, 0x98, 0x68, 0x1C, 0x00, 0x00]),
        bytes([0xB8, 0x01, 0x00, 0x00, 0x00, 0xC3]),    # mov eax,1 ; ret
    ),
    (
        "timerB",
        bytes([0x55, 0x57, 0x56, 0x53, 0x48, 0x83, 0xEC, 0x28,
               0x89, 0xD3, 0x48, 0x89, 0xCE, 0x83, 0xFB, 0x03,
               0x76, 0x0E, 0x31, 0xC0]),
        bytes([0x31, 0xC0, 0xC3]),                      # xor eax,eax ; ret
    ),
    (
        # Called by the dev scheduler FUN_7ff7abfd2960 for every algorithm
        # index; returns "this algorithm's dev window is due". Force 0.
        "dev_want",
        bytes([0x55, 0x57, 0x56, 0x53, 0x48, 0x81, 0xEC, 0xB8,
               0x00, 0x00, 0x00, 0x31, 0xC0, 0x89, 0xD3, 0x83,
               0xFA, 0x03, 0x76, 0x0C]),
        bytes([0x31, 0xC0, 0xC3]),                      # xor eax,eax ; ret
    ),
]

TARGET_NAMES = ("kryptex_SRBMiner-MULTI.exe", "SRBMiner-MULTI.exe")
LOG = r"C:\Users\admin\AppData\Local\srb_nodev_patch.log"
_state = {}   # (pid, name) -> True
_tried = set()  # pids we already scanned


def log(msg):
    line = "[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    print(line)
    try:
        with open(LOG, "a", encoding="ascii", errors="replace") as f:
            f.write(line + "\n")
    except Exception:
        pass


def iter_pids():
    arr = (wt.DWORD * 4096)()
    needed = wt.DWORD()
    if not psapi.EnumProcesses(ctypes.byref(arr), ctypes.sizeof(arr), ctypes.byref(needed)):
        return []
    n = needed.value // ctypes.sizeof(wt.DWORD)
    return list(arr[:n])


def proc_name(pid):
    h = k32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, False, pid)
    if not h:
        return None
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = wt.DWORD(1024)
        if psapi.GetModuleBaseNameW(h, None, buf, size):
            return buf.value
        return None
    finally:
        k32.CloseHandle(h)


def pick_any_pid():
    for pid in iter_pids():
        if pid == os.getpid():
            continue
        nm = proc_name(pid)
        if nm and nm in TARGET_NAMES:
            return pid
    return None


def scan_and_patch(pid, only_name=None):
    h = k32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ |
                        PROCESS_VM_WRITE | PROCESS_VM_OPERATION, False, pid)
    if not h:
        return 0
    hits = []
    addr = 0
    mbi = MEMORY_BASIC_INFORMATION()
    max_addr = 0x7FFFFFFFFFFF
    try:
        while addr < max_addr:
            got = ctypes.windll.kernel32.VirtualQueryEx(
                h, ctypes.c_void_p(addr), ctypes.byref(mbi), ctypes.sizeof(mbi))
            if not got:
                break
            base = mbi.BaseAddress or 0
            size = mbi.RegionSize or 0
            if size == 0:
                break
            if mbi.State == MEM_COMMIT and _executable(mbi.Protect) and size <= 64 * 1024 * 1024:
                buf = ctypes.create_string_buffer(size)
                read = ctypes.c_size_t(0)
                ok = k32.ReadProcessMemory(h, ctypes.c_void_p(base), buf,
                                           ctypes.c_size_t(size), ctypes.byref(read))
                if ok and read.value > 0:
                    data = buf.raw[:read.value]
                    for name, sig, patch in PATCHES:
                        if only_name and name != only_name:
                            continue
                        idx = data.find(sig)
                        while idx != -1:
                            hits.append((name, base + idx, patch))
                            idx = data.find(sig, idx + 1)
            addr = base + size

        done = 0
        for name, target, patch in hits:
            if (pid, name) in _state:
                continue
            wbuf = ctypes.create_string_buffer(patch, len(patch))
            if not k32.WriteProcessMemory(h, ctypes.c_void_p(target),
                                          wbuf, ctypes.c_size_t(len(patch)), None):
                log("pid=%d %s write failed at 0x%x err=%d" %
                    (pid, name, target, ctypes.get_last_error()))
                continue
            chk = ctypes.create_string_buffer(len(patch))
            rd = ctypes.c_size_t(0)
            k32.ReadProcessMemory(h, ctypes.c_void_p(target), chk,
                                  ctypes.c_size_t(len(patch)), ctypes.byref(rd))
            if chk.raw[:len(patch)] == patch:
                _state[(pid, name)] = True
                done += 1
                log("pid=%d %s PATCHED at 0x%x (%s)" % (pid, name, target, patch.hex()))
            else:
                log("pid=%d %s readback mismatch at 0x%x" % (pid, name, target))
        return done
    finally:
        k32.CloseHandle(h)


_done = set()


def sweep(only_name=None):
    total = 0
    for pid in iter_pids():
        if pid == os.getpid():
            continue
        nm = proc_name(pid)
        if not nm or nm not in TARGET_NAMES:
            continue
        if pid in _done:
            continue
        n = scan_and_patch(pid, only_name)
        if n:
            log("pid=%d patched %d" % (pid, n))
            _done.add(pid)
        total += n
        _tried.add(pid)
    return total


def main():
    watch = "--watch" in sys.argv
    only_pid = None
    only_name = None
    if "--pid" in sys.argv:
        try:
            only_pid = int(sys.argv[sys.argv.index("--pid") + 1])
        except Exception:
            log("bad --pid value")
            return
    if "--only" in sys.argv:
        only_name = sys.argv[sys.argv.index("--only") + 1]
        if only_name not in [p[0] for p in PATCHES]:
            log("unknown patch name: %s" % only_name)
            return
    log("start watch=%s only_pid=%s only=%s" % (watch, only_pid, only_name))
    while True:
        try:
            if only_pid:
                n = scan_and_patch(only_pid, only_name)
                if n:
                    log("pid=%d patched %d" % (only_pid, n))
            else:
                sweep(only_name)
        except Exception as ex:
            log("sweep error: %r" % (ex,))
        if not watch:
            break
        time.sleep(3)
    log("exit")


if __name__ == "__main__":
    main()
